/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.contacteditor;

/**
 *
 * @author Rjk15
 */
public class ErrRecIntegralVal extends Exception {
    public ErrRecIntegralVal(String message) {
        super (message);
    }
}
    
